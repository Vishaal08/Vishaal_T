// import { Component, OnInit } from '@angular/core';
// import { CommonModule } from '@angular/common';
// import { RouterLink } from '@angular/router';
// import { BookService, Book } from '../book.service';

// @Component({
//   selector: 'app-booklist',
//   standalone: true,
//   imports: [CommonModule, RouterLink],
//   templateUrl: './booklist.component.html',
//   styleUrls: ['./booklist.component.css']
// })
// export class BookListComponent implements OnInit {
//   books: Book[] = [];

//   constructor(private bookService: BookService) {}

//   ngOnInit(): void {
//     this.bookService.getBooks().subscribe({
//       next: (data) => this.books = data,
//       error: (err) => console.error('Error fetching books', err)
//     });
//   }
// }

import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { BookService, Books} from '../book.service';

@Component({
  selector: 'app-booklist',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './booklist.component.html',
  styleUrls: ['./booklist.component.css']
})
export class BookListComponent implements OnInit {
  books: Books[] = [];
  errorMessage: string = '';
  successMessage: string = '';

  constructor(private bookService: BookService) {}

  ngOnInit(): void {
    this.loadBooks();
  }

  loadBooks(): void {
    this.bookService.getBooks().subscribe({
      next: (data) => this.books = data,
      error: (err) => console.error('Error fetching books', err)
    });
  }

  deleteBook(id?: number): void {
    if (id === undefined) {
      console.error('ID is undefined');
      return;
    }

    if (confirm('Are you sure you want to delete this book?')) {
      this.bookService.deleteBook(id).subscribe({
        next: () => {
          this.successMessage = 'Book deleted successfully!';
          this.loadBooks();  // Reload the list of books after deletion
        },
        error: (err) => {
          console.error('Error deleting book', err);
          this.errorMessage = 'Failed to delete book.';
        }
      });
    }
  }
}
