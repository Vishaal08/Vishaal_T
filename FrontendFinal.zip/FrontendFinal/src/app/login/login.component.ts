import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  standalone: true,
  imports: [CommonModule, FormsModule],
})
export class LoginComponent {
  username: string = '';
  password: string = '';
  errorMessage: string = '';

  constructor(private router: Router) {}

  onSubmit(form: any): void {
    if (form.valid) {
      if (this.username === 'Vishaal' && this.password === '1234') {
        // Successful login, navigate to the books page
        this.router.navigate(['/books']);
      } else {
        // Invalid credentials
        this.errorMessage = 'Invalid credentials. Please try again.';
      }
    } else {
      this.errorMessage = 'Please fill in all required fields.';
    }
  }
}
