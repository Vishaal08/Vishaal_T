import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { BookService, Books } from '../book.service';
import { RouterLink } from '@angular/router';
import { Router } from 'express';

@Component({
  selector: 'app-bookdetail',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './bookdetail.component.html',
  styleUrls: ['./bookdetail.component.css']
})
export class BookDetailComponent implements OnInit {
  book: Books | undefined;

  constructor(private bookService: BookService, private route: ActivatedRoute) {}

  ngOnInit(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.bookService.getBook(id).subscribe(data => {
      this.book = data;
    });
  }
  
  
}
