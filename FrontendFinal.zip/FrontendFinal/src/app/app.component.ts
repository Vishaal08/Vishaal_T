import { Component } from '@angular/core';
import { RouterOutlet, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink],
  template: `
    <nav style="text-align: center;">
      <ul>
        <li><a routerLink="/books">Book List</a></li>
        <li><a routerLink="/add">Add Book</a></li>
      </ul>
    </nav>
    <router-outlet></router-outlet>
  `,
  styles: [`
    nav {
      background-color: #333;
      padding: 10px;
    }
    nav ul {
      list-style-type: none;
      padding: 0;
    }
    nav ul li {
      display: inline;
      margin-right: 10px;
    }
    nav ul li a {
      color: white;
      text-decoration: none;
    }
  `]
})
export class AppComponent {
  title = 'Book Management';
}
