import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { BookService, Books } from '../book.service';

@Component({
  selector: 'app-updatebook',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './updatebook.component.html',
  styleUrls: ['./updatebook.component.css']
})
export class UpdateBookComponent implements OnInit {
  book: Books = { title: '', author: '', genre: '', status: 'available' };

  constructor(
    private bookService: BookService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.bookService.getBook(id).subscribe(data => {
      this.book = data;
    });
  }

  updateBook(): void {
    this.bookService.updateBook(this.book.id!, this.book).subscribe(() => {
      this.router.navigate(['/books']);
    });
  }
}

