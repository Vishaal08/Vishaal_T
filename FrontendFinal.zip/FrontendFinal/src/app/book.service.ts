import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { catchError, Observable, throwError } from 'rxjs';

export interface Books {
  id?: number;
  title: string;
  author: string;
  genre: string;
  status: string;
}

const apiUrl = 'http://localhost:8762'; 

@Injectable({
  providedIn: 'root'
})
export class BookService {
  constructor(private http: HttpClient) {}

  getBooks(): Observable<Books[]> {
    return this.http.get<Books[]>(`${apiUrl}/getbook`).pipe(
      catchError(this.handleError)
    );
  }

  getBook(id: number): Observable<Books> {
    return this.http.get<Books>(`${apiUrl}/getbook/${id}`).pipe(
      catchError(this.handleError)
    );
  }

  addBook(book: Books): Observable<Books> {
    return this.http.post<Books>(`${apiUrl}/addbook`, book).pipe(
      catchError(this.handleError)
    );
  }

  updateBook(id: number, book: Books): Observable<Books> {
    return this.http.put<Books>(`${apiUrl}/updatebook/${id}`, book).pipe(
      catchError(this.handleError)
    );
  }

  deleteBook(id: number): Observable<void> {
    return this.http.delete<void>(`${apiUrl}/deletebook/${id}`).pipe(
      catchError(this.handleError)
    );
  }

  private handleError(error: HttpErrorResponse) {
    let errorMessage = 'An unknown error occurred!';
    if (error.error instanceof ErrorEvent) {
      // Client-side error
      errorMessage = `Error: ${error.error.message}`;
    } else {
      // Server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    console.error(errorMessage);
    return throwError(() => new Error(errorMessage));
  }
}