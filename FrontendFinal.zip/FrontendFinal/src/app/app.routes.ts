import { Routes } from '@angular/router';
import { BookListComponent } from './booklist/booklist.component';
import { AddBookComponent } from './addbook/addbook.component';
import { UpdateBookComponent } from './updatebook/updatebook.component';
import { BookDetailComponent } from './bookdetail/bookdetail.component';
import { LoginComponent } from './login/login.component';

export const routes: Routes = [
    { path: 'login', component: LoginComponent },
    

  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: 'books', component: BookListComponent },
  { path: 'add', component: AddBookComponent },
  { path: 'update/:id', component: UpdateBookComponent },
  { path: 'book/:id', component: BookDetailComponent }
];
