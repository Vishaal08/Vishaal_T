import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { BookService, Books } from '../book.service';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-addbook',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './addbook.component.html',
  styleUrls: ['./addbook.component.css']
})
export class AddBookComponent {
  book: Books = {
    title: '',
    author: '',
    genre: '',
    status: 'available'
  };
  errorMessage: string = '';
  successMessage: string = '';

  constructor(private bookService: BookService, private router: Router) {}

  // onSubmit(form: NgForm): void {
  //   if (form.valid) {
  //     this.bookService.addBook(this.book).subscribe({
  //       next: (response) => {
  //         console.log('Book added successfully', response);
  //         this.successMessage = 'Book added successfully!';
  //         setTimeout(() => this.router.navigate(['/books']), 2000);
  //       },
  //       error: (err: HttpErrorResponse) => {
  //         console.error('Detailed error adding book:', err);
  //         if (err.error instanceof ErrorEvent) {
  //           // Client-side error
  //           this.errorMessage = `Client-side error: ${err.error.message}`;
  //         } else {
  //           // Server-side error
  //           this.errorMessage = `Server-side error: Status ${err.status}, Message: ${err.message}`;
  //           if (err.error) {
  //             console.error('Server error details:', err.error);
  //             this.errorMessage += `\nServer details: ${JSON.stringify(err.error)}`;
  //           }
  //         }
  //       }
  //     });
  //   } else {
  //     this.errorMessage = 'Please fill in all required fields.';
  //   }
  // }

  onSubmit(form: NgForm): void {
    if (form.valid) {
        console.log('Form is valid, sending book data:', this.book);
        this.bookService.addBook(this.book).subscribe({
            next: (response) => {
                console.log('Book added successfully', response);
                this.successMessage = 'Book added successfully!';
                setTimeout(() => this.router.navigate(['/books']), 2000);
            },
            error: (err: HttpErrorResponse) => {
                console.error('Detailed error adding book:', err);
                this.handleHttpError(err);
            }
        });
    } else {
        this.errorMessage = 'Please fill in all required fields.';
    }
}
goBack() {
  this.router.navigate(['/books']);
}

private handleHttpError(err: HttpErrorResponse): void {
    if (err.error instanceof ErrorEvent) {
        // Client-side error
        this.errorMessage = `Client-side error: ${err.error.message}`;
    } else {
        // Server-side error
        this.errorMessage = `Server-side error: Status ${err.status}, Message: ${err.message}`;
        console.error('Server error details:', err.error);
        if (err.error) {
            this.errorMessage += `\nServer details: ${JSON.stringify(err.error)}`;
        }
    }
}


  
}