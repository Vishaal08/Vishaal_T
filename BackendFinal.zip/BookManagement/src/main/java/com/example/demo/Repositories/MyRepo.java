
package com.example.demo.Repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.Models.Books;

public interface MyRepo extends JpaRepository<Books,Integer>{

	List<Books> findByStatus(String status);

	 

}