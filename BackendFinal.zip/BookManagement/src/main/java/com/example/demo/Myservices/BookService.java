//package com.example.demo.Myservices;
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.example.demo.Exceptions.booknotfoundexception;
//import com.example.demo.Models.Books;
//import com.example.demo.Repositories.MyRepo;
//import com.example.demo.Repositories.ReviewRepo;
//
//@Service
//public class BookService {
//	@Autowired
//	private MyRepo repo;
//	@Autowired
//	private ReviewRepo repo1;
//	
//	public List<Books> getallbooks()
//	{
//		return repo.findAll();
//	}
//	
//	public Books getbookbyid(int id)
//	{
//		return repo.findById(id).orElseThrow(() -> new booknotfoundexception("Book not found"));
//		
//		
//	}
//	
//	public Books addbook(Books book)
//	{
//		return repo.save(book);
//	}
//	public Books updatebook(int id, Books updatedBook) {
//        Books b = getbookbyid(id);
//        b.setTitle(updatedBook.getTitle());
//        b.setAuthor(updatedBook.getAuthor());
//        b.setGenre(updatedBook.getGenre());
//        b.setStatus(updatedBook.getStatus());
//        return repo.save(b);
//    }
//	
//	public void deletebook(int id)
//	{
//		Books b=getbookbyid(id);
//		repo.delete(b);
//		
//	}
//	
//	public List<Books> getbookbystatus(String status)
//	{
//		return repo.findByStatus(status);
//	}
//
//}

package com.example.demo.Myservices;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Exceptions.booknotfoundexception;
import com.example.demo.Models.Books;
//import com.example.demo.Models.Reviews;
import com.example.demo.Repositories.MyRepo;
//import com.example.demo.Repositories.ReviewRepo;


import java.util.List;

@Service
public class BookService {

    @Autowired
    private MyRepo bookRepository;

//    @Autowired
//    private ReviewRepo reviewRepository;

    public List<Books> getallbooks() {
        return bookRepository.findAll();
    }

    public Books getbookbyid(int id) {
        return bookRepository.findById(id).orElseThrow(() -> new booknotfoundexception("Book not found"));
    }

    public Books addbook(Books book) {
        return bookRepository.save(book);
    }

    public Books updatebook(int id, Books book) {
        if (bookRepository.existsById(id)) {
            book.setId(id);
            return bookRepository.save(book);
        }
        return null;
    }

    public void deletebook(int id) {
        bookRepository.deleteById(id);
    }

    public List<Books> getbookbystatus(String status) {
        return bookRepository.findByStatus(status);
    }
}

