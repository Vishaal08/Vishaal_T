package com.example.demo.Models;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.*;

@Entity
@Table(name = "books")
public class Books {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String title;
    private String author;
    private String genre;

    @Column(nullable = false)
    private String status;

//    @OneToOne(mappedBy = "book", cascade = CascadeType.ALL, orphanRemoval = true)
//    @JsonManagedReference
//    private Reviews review;

    

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
//	public Reviews getReview() {
//	    return review;
//	}
//
//	public void setReview(Reviews review) {
//	    this.review = review;
//	}

}
