package com.example.demo.MyController;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Models.Books;
import com.example.demo.Myservices.BookService;

@RestController
@CrossOrigin(origins = "http://localhost:61139/")

public class BookController {

	@Autowired
	private BookService service;
	 
	@GetMapping("/")
	public String entrypage(){ 
		
			return "<h1>Welcome to SpringBoot Book Management Project</h1>";
	}
	
	@GetMapping("/getbook")
	public List<Books>BookList(){ 
		List<Books> books=new ArrayList<>();
		 books =service.getallbooks();
		return books;
	}
	
	@GetMapping("/getbook/{id}")
	public Books BookListbyId(@PathVariable int id){ 
		return service.getbookbyid(id);
		 
	}
	
//	@PostMapping("/addbook")
//	public Books addbooks(@RequestBody Books book){ 
//		
//		return service.addbook(book);
//		
//	}
	@PostMapping("/addbook")
	public ResponseEntity<Books> addbooks(@RequestBody Books book) {
	    try {
	        Books savedBook = service.addbook(book);
	        return ResponseEntity.ok(savedBook);
	    } catch (Exception e) {
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
	    }
	}

//	@PostMapping("/addbook")
//	public ResponseEntity<?> addbooks(@RequestBody Books book) {
//	    try {
//	        Books savedBook = service.addbook(book);
//	        return ResponseEntity.ok(savedBook);
//	    } catch (Exception e) {
//	        // Log the full stack trace
//	        e.printStackTrace();
//	        // Return a more detailed error message
//	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error adding book: " + e.getMessage());
//	    }
//	}

	@PutMapping("/updatebook/{id}")
	public Books updatebook(@PathVariable int id,@RequestBody Books book){ 
		
		return service.updatebook(id, book);
		
	}
	
	@DeleteMapping("/deletebook/{id}")
	public String deletebokbyId(@PathVariable int id){ 
		service.deletebook(id);
		return "Deleted";
		
	
	}
	
	@GetMapping("/getbooks/{status}")
	public List<Books>BookListByStatus(@PathVariable String status){ 
		List<Books> books=new ArrayList<>();
		 books =service.getbookbystatus(status);
		return books;
	}
}