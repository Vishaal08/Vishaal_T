package com.example.demo.Exceptions;

public class booknotfoundexception extends RuntimeException {
	public booknotfoundexception(String msg)
	{
		super(msg);
	}

}
